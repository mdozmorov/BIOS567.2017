RGraphics
=========

Getting Started with R Graphics workshop materials. For workshop offered through the Univ of Virginia Library. 

Topics include the R graphics framework, ggplot2, and taking advantage of canned plotting functions in R packages. 
